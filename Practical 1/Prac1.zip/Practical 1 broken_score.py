"""
CP1404/CP5632 - Practical
Broken program to determine score status
"""

# TODO: Fix this!

score = float(input("Enter score: "))
if score < 0:
    print("Invalid score")
else:
    if score > 100:
        print("Invalid score")
    if 50 <= score < 90:
        print("Passable")
    if 90 <= score <= 100:
        print("Excellent")
    if score < 50:
        print("Bad")