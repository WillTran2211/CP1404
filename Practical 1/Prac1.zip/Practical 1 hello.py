
print('hello world')